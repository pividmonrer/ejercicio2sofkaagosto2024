package com.demoblaze.api;

import com.intuit.karate.junit5.Karate;

public class ApiTestRunner {

    @Karate.Test
    Karate testSignup() {
        return Karate.run("classpath:com/demoblaze/api/signup.feature").relativeTo(getClass());
    }

    @Karate.Test
    Karate testLogin() {
        return Karate.run("classpath:com/demoblaze/api/login.feature").relativeTo(getClass());
    }
}
